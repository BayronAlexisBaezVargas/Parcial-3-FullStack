package com.perfulandia.perfumeria_carrito;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PerfumeriaCarritoApplicationTests {

	@Test
	void contextLoads() {
	}

}
