package com.perfulandia.perfumeria_carrito.repository;

import com.perfulandia.perfumeria_carrito.model.Carrito;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CarritoRepository extends JpaRepository<Carrito, Long>{

}
