package com.perfulandia.productservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PerfulandiaProductoApplicationTests {

	@Test
	void contextLoads() {
	}

}
