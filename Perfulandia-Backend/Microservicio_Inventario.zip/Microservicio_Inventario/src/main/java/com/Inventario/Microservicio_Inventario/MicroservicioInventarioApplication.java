package com.Inventario.Microservicio_Inventario;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroservicioInventarioApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicioInventarioApplication.class, args);
	}
}
