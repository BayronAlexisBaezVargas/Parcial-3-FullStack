package com.Inventario.Microservicio_Inventario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicioProductoStockApplicationTests {

	@Test
	void contextLoads() {
	}

}
