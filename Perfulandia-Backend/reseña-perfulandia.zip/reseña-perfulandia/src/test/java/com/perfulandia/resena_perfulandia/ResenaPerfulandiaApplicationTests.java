package com.perfulandia.resena_perfulandia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResenaPerfulandiaApplicationTests {

	@Test
	void contextLoads() {
	}

}
