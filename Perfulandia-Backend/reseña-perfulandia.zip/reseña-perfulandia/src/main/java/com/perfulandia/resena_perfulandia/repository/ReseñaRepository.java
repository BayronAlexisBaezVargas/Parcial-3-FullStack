package com.perfulandia.resena_perfulandia.repository;

import com.perfulandia.resena_perfulandia.model.Reseña;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReseñaRepository extends JpaRepository<Reseña, Long> {

}
