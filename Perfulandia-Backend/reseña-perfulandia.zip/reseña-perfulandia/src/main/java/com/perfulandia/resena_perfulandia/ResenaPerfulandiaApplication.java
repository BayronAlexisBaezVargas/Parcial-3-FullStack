package com.perfulandia.resena_perfulandia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResenaPerfulandiaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResenaPerfulandiaApplication.class, args);
	}

}
